package entity;

import java.awt.Dimension;
import java.util.ArrayList;

public class Engine {
	private Dimension dimension ;
	private Cell grid[][];
	
	public Engine(int l, int c) {
		this.dimension = new Dimension(l,c);
		this.grid = new Cell[l][c];
		
		for (int i = 0; i < l; i++) {
			for (int j = 0; j < c; j++) {
				this.grid[i][j] = new Cell(0);
			}
		}
	}
	
	public Engine(int[][] vals) {
		this.dimension = new Dimension(vals.length,vals[0].length);
		this.grid = new Cell[vals.length][vals[0].length];
		
		for (int i = 0; i < vals.length; i++) {
			for (int j = 0; j < vals[0].length; j++) {
				this.grid[i][j] = new Cell(vals[i][j]);
			}
		}
	}
	
	public int getWidth() {
		return (int) this.dimension.getWidth();
	}
	
	public int getHeight() {
		return (int) this.dimension.getHeight();
	}
	
	public int getCell(int i, int j) {
		return this.grid[i][j].getContent();
	}
	
	public void setCell(int i, int j, int v) {
		this.grid[i][j].setContent(v);
	}
	
	public ArrayList<Cell> getEmptyCells() {
		ArrayList<Cell> liste = new ArrayList<Cell>();
		for (int i = 0; i < this.getWidth(); i++) {
			for (int j = 0; j < this.getHeight(); j++) {
				if (this.grid[i][j].getContent() == 0) {
					liste.add(this.grid[i][j]);
				}
			}
		}
		return liste;
	}
	
	private static int genRandInt(int min, int max) {
		return (int)(min + (max - min) * Math.random());
	}
	
	public void addNewCell() {
		ArrayList<Cell> emptyCells = getEmptyCells();
		if ((emptyCells.size()) != 0) {
			int proba = genRandInt(0, 100);
			int value;
			if (proba < 80) {
				value = 2;
			} else {
				value = 4;
			}
			int cell = genRandInt(0, emptyCells.size());
			emptyCells.get(cell).setContent(value);
		}
	}
}
