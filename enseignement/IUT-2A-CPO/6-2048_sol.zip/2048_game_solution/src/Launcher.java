import javax.swing.SwingUtilities;

import boundary.MainWindow;
import control.Jeu2048;

public class Launcher implements Runnable{

	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Launcher());
	}

	@Override
	public void run() {
		new MainWindow(new Jeu2048());
	}

}
