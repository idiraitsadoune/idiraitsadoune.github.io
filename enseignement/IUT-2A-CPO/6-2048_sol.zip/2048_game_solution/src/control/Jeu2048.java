package control;

import entity.Engine;

public class Jeu2048 implements IControl {
	private Engine engine ;
	private static final int DIMENSION = 4 ;
	
	public Jeu2048() {
		this.init();
	}

	@Override
	public void init() {
		//this.engine = new Engine(new int[][]{{1,2,3,4},{5,6,7,8},{9,10,11,12},{13,14,15,16}});
		this.engine = new Engine(DIMENSION,DIMENSION);
		this.engine.addNewCell();
		this.engine.addNewCell();
	}

	@Override
	public int[][] getGrid() {
		int[][] grid = new int[this.engine.getHeight()][this.engine.getWidth()] ;
		
		for (int i = 0; i < grid.length; i++) {
			for (int j = 0; j < grid[0].length; j++) {
				grid[i][j] = this.engine.getCell(i, j);
			}
		}
		return grid;
	}
	
	private void rotate() {
		int[][] copy = this.getGrid();	
		for (int i = 0; i < copy.length; i++)
			for (int j = 0; j < copy[0].length; j++)
				this.engine.setCell(i, j, copy[this.engine.getWidth() - j - 1][i]);
	}
	
	private void moveRight() {
		for (int i = 0; i <this.engine.getHeight(); i++) {
			int[] copy = new int[this.engine.getWidth()];
			int k = this.engine.getWidth() - 1;
			for (int j = this.engine.getWidth() - 1; j >= 0; j--) {
				if (this.engine.getCell(i,j) != 0) {
					copy[k] = this.engine.getCell(i,j);
					k--;
				}
			}
			for (int j = 0; j < this.engine.getWidth(); j++) {
				this.engine.setCell(i, j, copy[j]);
			}
		}
	}
	
	private void fuseRight() {
		for (int i = 0; i < this.engine.getHeight(); i++) {
			for (int j = this.engine.getWidth() - 1; j > 0; j--) {
				if (this.engine.getCell(i,j) == this.engine.getCell(i,j-1)) {
					this.engine.setCell(i,j,this.engine.getCell(i,j)*2); 
					this.engine.setCell(i,j-1,0); 
				}
			}
		}
	}

	private boolean isSame(int[][] a, int[][] b) {
		for(int i=0; i<a.length; i++)
			for(int j=0; j<a[0].length; j++) {
				if(a[i][j] != b[i][j]) return false;
			}
		return true ;
	}
	
	@Override
	public void right() {
		int[][] before = this.getGrid();
		
		this.moveRight();
		this.fuseRight();
		this.moveRight();
		
		int[][] after = this.getGrid();
		if(! this.isSame(after, before)) this.engine.addNewCell();
	}

	@Override
	public void down() {
		this.rotate();
		this.rotate();
		this.rotate();
		right();
		this.rotate();
	}

	@Override
	public void up() {
		this.rotate();
		right();
		this.rotate();
		this.rotate();
		this.rotate();
	}

	@Override
	public void left() {
		this.rotate();
		this.rotate();
		right();
		this.rotate();
		this.rotate();
	}
	
	@Override
	public boolean isOver() {
		if(this.engine.getEmptyCells().size()>0) return false;
		
		for (int i = 0; i < this.engine.getHeight(); i++) {
			for (int j = 0; j < this.engine.getWidth(); j++) {
				if (i!=this.engine.getHeight()-1 && this.engine.getCell(i,j)==this.engine.getCell(i+1,j)) {
					return false;
				}
				if (j!=this.engine.getWidth()-1 && this.engine.getCell(i, j)==this.engine.getCell(i,j+1)) {
					return false;
				}
			}
		}
		
		return true ;
	}

	@Override
	public int score() {
		int max = 0;

		for (int i = 0; i < this.engine.getHeight(); i++) {
			for (int j = 0; j < this.engine.getWidth(); j++) {
				if (this.engine.getCell(i, j) > max)
					max = this.engine.getCell(i, j);
			}
		}

		return max;
	}

}
