package entity;

public class Cell {
	private int content ;

	public Cell(int content) {
		this.content = content;
	}

	public int getContent() {
		return content;
	}

	public void setContent(int content) {
		this.content = content;
	}
	
}
