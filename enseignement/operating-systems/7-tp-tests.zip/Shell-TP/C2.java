public class C2{
    private int att1
}