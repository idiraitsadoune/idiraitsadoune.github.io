public class C6{
    private int att1 ;
    private int att2 ;

    public static void main(String[] args){
        -- System.out.println("Hello !")
    }
}