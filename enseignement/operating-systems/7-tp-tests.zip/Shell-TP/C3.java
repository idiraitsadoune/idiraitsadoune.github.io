public class C3{
    public void main(){
        System.out.println("Hello !");
    }
}